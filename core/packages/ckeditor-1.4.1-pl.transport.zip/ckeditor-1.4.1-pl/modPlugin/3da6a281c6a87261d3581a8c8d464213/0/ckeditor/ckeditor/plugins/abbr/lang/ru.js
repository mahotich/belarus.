﻿CKEDITOR.plugins.setLang( 'abbr', 'ru', {
    insert: 'Добавить аббревиатуру',
    edit: 'Редактировать аббревиатуру',
    firsttitle: 'Параметры аббревиатуры',
    basic: 'Основные настройки',
    advanced: 'Дополнительные настройки',
    abbreviation: 'Аббревиатура',
    abbreviation_ne: 'Поле Аббревиатура не должно быть пустым.',
    explanation: 'Расшифровка',
    explanation_ne: 'Поле Расшифровка не должно быть пустым.',
    id: 'Id'
} );