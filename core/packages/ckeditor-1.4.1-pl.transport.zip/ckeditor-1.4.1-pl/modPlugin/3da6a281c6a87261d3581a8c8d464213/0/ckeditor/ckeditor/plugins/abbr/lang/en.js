﻿CKEDITOR.plugins.setLang( 'abbr', 'en', {
	insert: 'Insert Abbreviation',
    edit: 'Edit Abbreviation',
    firsttitle: 'Abbreviation Properties',
    basic: 'Basic Settings',
    advanced: 'Advanced Settings',
    abbreviation: 'Abbreviation',
    abbreviation_ne: 'Abbreviation field cannot be empty.',
    explanation: 'Explanation',
    explanation_ne: 'Explanation field cannot be empty.',
    id: 'Id'
} );
